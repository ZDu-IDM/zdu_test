from COMPS.Data.WorkItems.BuilderWorkItem import BuilderWorkItem
